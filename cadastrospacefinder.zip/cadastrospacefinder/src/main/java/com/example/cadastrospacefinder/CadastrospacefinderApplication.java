package com.example.cadastrospacefinder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CadastrospacefinderApplication {

	public static void main(String[] args) {
		SpringApplication.run(CadastrospacefinderApplication.class, args);
	}

}
