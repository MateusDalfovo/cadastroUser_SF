package com.example.cadastrospacefinder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CadastrospacefinderApplicationTests {

	@Test
	void contextLoads() {
	}

}
